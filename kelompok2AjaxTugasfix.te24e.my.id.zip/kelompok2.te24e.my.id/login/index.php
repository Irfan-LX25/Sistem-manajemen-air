<?php
session_start();
if(empty($_SESSION['user']) && empty($_SESSION['pass'])){
    echo"<script>window.location.replace('../index.php');</script>";
}

include '../assets/func.php';
$air=new klas_air();
$koneksi=$air->koneksi();
$dt_user=$air->dt_user($_SESSION['user']);
$user_level=$dt_user[2];
$pass2 = '';

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['get_last_meter']) && $_POST['get_last_meter'] == '1'){
    if(isset($_POST['username'])){
        $username = $_POST['username'];
        
        $q = mysqli_query($koneksi, "SELECT meter_akhir FROM pemakaian WHERE username='$username' ORDER BY tgl DESC, no DESC LIMIT 1");
        
        if($q && mysqli_num_rows($q) > 0){
            $d = mysqli_fetch_row($q);
            $meter_terakhir = $d[0];
        } else {
            $meter_terakhir = 0; 
        }
        
        header('Content-Type: application/json');
        echo json_encode(['meter_awal' => $meter_terakhir]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['level'])) $level = $_POST['level'];
    if (isset($_POST['tipe'])) $tipe = $_POST['tipe'];
    if (isset($_POST['status'])) $status = $_POST['status'];
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - kelompok 2</title>
        <link rel="icon" href="../assets/img/polines.png"> 
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../css/styles.css?v=20260516-modern-card-v17" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>var user_level = "<?php echo $user_level; ?>";</script>
        <script src="../js/air.js"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">
                <span class="brand-title">Sistem Informasi<br><span>Manajemen Air</span></span>
            </a>
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars fa-fade"></i></button>
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search fa-beat"></i></button>
                </div>
            </form>
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw fa-fade"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Menu</div>
                            <a class="nav-link <?php if((!isset($_GET['page']) || $_GET['page'] == '') && !isset($_GET['p'])) echo 'active'; ?>" href="index.php">
                                <div class="sb-nav-link-icon icon-dashboard"><i class="fas fa-house fa-bounce"></i></div>
                                Dashboard
                            </a>
                            <?php
                            if ($user_level == 'Admin'){
                            ?>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-user') echo 'active'; ?>" href="index.php?page=manajemen-data-user">
                                <div class="sb-nav-link-icon icon-user"><i class="fas fa-users-gear fa-flip"></i></div>
                                    Manajemen User
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon icon-meter"><i class="fas fa-faucet-drip fa-fade"></i></div>
                                    Pemakaian Air Warga
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-tarif-air') echo 'active'; ?>" href="index.php?page=manajemen-data-tarif-air">
                                <div class="sb-nav-link-icon icon-tarif"><i class="fas fa-money-bill-wave fa-beat"></i></div>
                                    Manajemen Tarif Air
                            </a>
                            <?php
                            } elseif ($user_level == 'Bendahara') {
                            ?>
                            <!-- <a class="nav-link" href="index.php?page=ubah-data-meter-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-pen-to-square fa-shake text-warning"></i></div>
                                    Ubah Data Meter Warga
                            </a> -->
                            <!-- <a class="nav-link" href="index.php?page=hapus-data-meter-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-trash fa-bounce text-danger"></i></div>
                                    Hapus Data Meter Warga
                            </a> -->
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon icon-payment"><i class="fas fa-receipt fa-fade"></i></div>
                                    Lihat Pemakaian Warga
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-tarif-air') echo 'active'; ?>" href="index.php?page=manajemen-data-tarif-air">
                                <div class="sb-nav-link-icon icon-tarif"><i class="fas fa-money-bill-wave fa-beat"></i></div>
                                    Manajemen Data Tarif Air
                            </a>
                            <!-- <a class="nav-link" href="index.php?page=lihat-infografis-tagihan-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-line fa-fade text-info"></i></div>
                                    Lihat Infografis Tagihan Air
                            </a> -->
                            <?php
                            } elseif ($user_level == 'Warga') {
                            ?>
                            <a class="nav-link <?php if(isset($_GET['p']) && $_GET['p'] == 'pemakaian_sendiri_list') echo 'active'; ?>" href="index.php?p=pemakaian_sendiri_list">
                                <div class="sb-nav-link-icon icon-payment"><i class="fas fa-receipt fa-fade"></i></div>
                                    Lihat Pemakaian
                            </a>
                            <?php
                            }elseif ($user_level == 'Petugas') {
                            ?>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon icon-meter"><i class="fas fa-faucet-drip fa-fade"></i></div>
                                    Masukkan Data Meter Pemakaian Air
                            </a>
                            <!-- <a class="nav-link" href="index.php?page=ubah-data-meter-air-1-bulan-terakhir">
                                <div class="sb-nav-link-icon"><i class="fas fa-rotate fa-spin text-secondary"></i></div>
                                    Ubah Data Meter air 1 bulan terakhir
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-jumlah-total-pelanggan">
                                <div class="sb-nav-link-icon"><i class="fas fa-user-group fa-flip text-primary"></i></div>
                                    Lihat Jumlah Total Pelanggan
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-jumlah-pemakaian-air-seluruh-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-faucet-drip fa-beat text-success"></i></div>
                                    Lihat Jumlah Pemakaian Air Seluruh Warga
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-infografis-pemakaian-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-column fa-bounce text-info"></i></div>
                                    Lihat Infografis Pemakaian Air
                            </a> -->
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small"><i class="fa-solid fa-id-badge text-warning fa-fade"></i> Logged in as: <?php echo $dt_user[2]; ?></div>
                        <i class="fa-solid fa-location-dot text-danger fa-fade"></i> <?php echo $dt_user[0].' ('.$dt_user[1].')'; ?> 
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 content-wrap">
                        <?php
                        $e = explode('=', $_SERVER['REQUEST_URI']);
                        if (!empty($e[1])) {
                            if ($e[1] == 'manajemen-data-user' || $e[1] == 'user_edit&user'){
                                $h1 = 'Manajemen Data User';
                                $li = 'Menu untuk CRUD User';
                            }elseif ($e[1] == 'manajemen-data-tarif-air'|| $e[1] == 'tarif_edit&kode_tarif'){
                                $h1 = 'Manajemen Data Tarif Air';
                                $li = 'Menu untuk memanajemen data tarif air';
                            }elseif ($e[1] == 'manajemen-pemakaian-air'){
                                $h1 = 'Manajemen Pemakaian Air';
                                $li = 'Menu untuk memanajemen data pemakaian air';
                            }elseif ($e[1] == 'ubah-data-meter-warga'){
                                $h1 = 'Ubah Data Meter Warga';
                                $li = 'Menu untuk mengubah data meter warga';
                            }elseif ($e[1] == 'hapus-data-meter-warga'){
                                $h1 = 'Hapus Data Meter Warga';
                                $li = 'Menu untuk menghapus data meter warga'; 
                            }elseif ($e[1] == 'lihat-tagihan-seluruh-warga'){
                                $h1 = 'Lihat Tagihan Seluruh Warga';
                                $li = 'Menu untuk melihat tagihan seluruh warga';
                            }elseif ($e[1] == 'lihat-infografis-tagihan-air'){
                                $h1 = 'Lihat Infografis Tagihan Air';
                                $li = 'Menu untuk melihat infografis tagihan air';
                            }elseif ($e[1] == 'pantau-pemakaian-air-tiap-bulan'){
                                $h1 = 'Pantau Pemakaian Air Tiap Bulan';
                                $li = 'Menu untuk memantau pemakaian air tiap bulan';
                            }elseif ($e[1] == 'lihat-tagihan-tiap-bulan'){
                                $h1 = 'Lihat Tagihan Tiap Bulan';
                                $li = 'Menu untuk melihat tagihan tiap bulan';
                            }elseif ($e[1] == 'lihat-infografis-tagihan-dan-pemakaian-air-bulanan'){
                                $h1 = 'Lihat Infografis Tagihan dan Pemakaian Air Bulanan';
                                $li = 'Menu untuk melihat infografis tagihan dan pemakaian air bulanan';
                            }elseif ($e[1] == 'pemakaian_sendiri_list'){
                                $h1 = 'Pemakaian & Tagihan Air';
                                $li = 'Data Pemakaian & Tagihan Air';
                            }elseif ($e[1] == 'masukkan-data-meter-pemakaian-air'|| $e[1] == 'meter_edit&no'){
                                $h1 = 'Masukkan Data Meter Pemakaian Air';
                                $li = 'Menu untuk memasukkan data meter pemakaian air';
                            }elseif ($e[1] == 'ubah-data-meter-air-1-bulan-terakhir'){
                                $h1 = 'Ubah Data Meter Air 1 Bulan Terakhir';
                                $li = 'Menu untuk mengubah data meter air 1 bulan terakhir';
                            }elseif ($e[1] == 'lihat-jumlah-total-pelanggan'){
                                $h1 = 'Lihat Jumlah Total Pelanggan';
                                $li = 'Menu untuk melihat jumlah total pelanggan';
                            }elseif ($e[1] == 'lihat-jumlah-pemakaian-air-seluruh-warga'){
                                $h1 = 'Lihat Jumlah Pemakaian Air Seluruh Warga';
                                $li = 'Menu untuk melihat jumlah pemakaian air seluruh warga';
                            }elseif ($e[1] == 'lihat-infografis-pemakaian-air'){
                                $h1 = 'Lihat Infografis Pemakaian Air';
                                $li = 'Menu untuk melihat infografis pemakaian air';
                        }
                        }else {
                            $h1 = 'Dashboard';
                            $li = 'Selamat datang di dashboard';
                        }                       
                        ?>
                        <h1><?php echo $h1; ?></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><?php echo $li; ?></li>
                        </ol>
                        <div class="row" id="summary">
                            <div class="row mb-3" id="pilih_waktu">
                                <div class="col-xl-3 col-md-12">
                                    <label for="sel1" class="form-label">Pilih Waktu:</label>
                                    <select class="form-select" id="sel1" name="pilih_waktu">
                                        <option value="">Bulan</option>
                                        <?php
                                        for ($i = 1; $i <= 12; $i++) {
                                            if ($i < 10) $i = "0".$i;
                                            echo "<option value=".date('Y')."-".$i.">".$air->bln($i)." ".date('Y')."</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <?php if ($user_level == 'Warga') { ?>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3"></div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white">Waktu Pencatatan</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3">m<sup>3</sup></div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white">Pemakaian Air</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3">Rp</div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white">Tagihan</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1 class="text-uppercase" style="font-size: 2.2rem; font-weight: bold;"></h1>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white">Status Tagihan</div>
                                    </div>
                                </div>
                            </div>
                            <?php } else { ?>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3">orang</div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white">Pelanggan</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3"><?php echo ($user_level == 'Bendahara') ? 'Rp' : 'm<sup>3</sup>'; ?></div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white"><?php echo ($user_level == 'Bendahara') ? 'Pemasukan' : 'Pemakaian Air'; ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3">warga</div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white"><?php echo ($user_level == 'Bendahara') ? 'Sudah Lunas' : 'Sudah Dicatat'; ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body d-flex justify-content-center">
                                        <h1></h1>
                                        <div class="ms-3">warga</div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-center">
                                        <div class="small text-white"><?php echo ($user_level == 'Bendahara') ? 'Belum Bayar' : 'Belum Dicatat'; ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="row" id="chart">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-line fa-bounce"></i>
                                        Area Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-column fa-bounce"></i>
                                        Bar Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                        </div>
                        <?php
                        if(isset($_POST['tombol'])){
                            $t=$_POST['tombol'];
                            if ($t == 'user_add'){
                                $user = $_POST['user'];
                                $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
                                $nama = $_POST['nama'];
                                $alamat = $_POST['alamat'];
                                $kota = $_POST['kota'];
                                $tlp = $_POST['tlp'];
                                $level = $_POST['level'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];
                                $qc = mysqli_query($koneksi, "SELECT username FROM login WHERE username='$user'");
                                $dc = mysqli_fetch_row($qc);

                                if (empty($dc)){
                                    mysqli_query($koneksi, "INSERT INTO login(username,password,nama,alamat,kota,tlp,level,tipe,status) VALUES ('$user','$pass','$nama','$alamat','$kota','$tlp','$level','$tipe','$status')");
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user berhasil ditambahkan...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user gagal ditambahkan...
                                        </div>";
                                    }
                                }
                                else {
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Username $user</strong> sudah ada, gunakan username lain...
                                    </div>";
                                }
                            }elseif($t == "user_edit"){
                                $user = $_POST['user'];
                                $pass = trim($_POST['password']);
                                $nama = $_POST['nama'];
                                $alamat = $_POST['alamat'];
                                $kota = $_POST['kota'];
                                $tlp = $_POST['tlp'];
                                $level = $_POST['level'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];

                                if ($pass === ''){
                                $qu = mysqli_query($koneksi, "UPDATE login SET nama=\"$nama\", alamat='$alamat', kota='$kota', tlp='$tlp', level='$level', tipe='$tipe', status='$status' WHERE username='$user'");
                                } else {
                                    $pass2 = password_hash($pass, PASSWORD_DEFAULT);
                                    $qu = mysqli_query($koneksi, "UPDATE login SET password='$pass2', nama=\"$nama\", alamat='$alamat', kota='$kota', tlp='$tlp', level='$level', tipe='$tipe', status='$status' WHERE username='$user'");
                                }
                                if ($qu === false) {
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user gagal diubah...
                                    </div>";
                                } elseif(mysqli_affected_rows($koneksi) > 0){
                                    echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user berhasil diubah...
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-user'; }, 1500);</script>";
                                } else {
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user tidak ada perubahan..
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-user'; }, 1500);</script>";
                                }
                            } elseif ($t =="user_hapus"){
                                $user = $_POST['user'];
                                mysqli_query($koneksi, "DELETE FROM login WHERE username='$user'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user gagal dihapus...
                                        </div>";
                                }
                            } elseif ($t == 'tarif_add'){
                                $kode_tarif = $_POST['kode_tarif'];
                                $tarif = $_POST['tarif'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];
                                    mysqli_query($koneksi, "INSERT INTO tarif(kd_tarif,tarif,tipe,status) VALUES ('$kode_tarif','$tarif','$tipe','$status')");
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif berhasil ditambahkan...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif gagal ditambahkan...
                                        </div>";
                                    }
                            } elseif($t == "tarif_edit"){
                                $kode_tarif = $_POST['kode_tarif'];
                                $tarif = $_POST['tarif'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];
                                mysqli_query($koneksi, "UPDATE tarif SET tarif='$tarif', tipe='$tipe', status='$status' WHERE kd_tarif='$kode_tarif'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                    echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> tarif berhasil diubah...
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-tarif-air'; }, 1500);</script>";
                                } else {
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> tarif tidak ada perubahan..
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-tarif-air'; }, 1500);</script>";
                                }
                            } elseif ($t =="tarif_hapus"){
                                $kode_tarif = $_POST['kode_tarif'] ?? ($_POST['tarif'] ?? '');
                                mysqli_query($koneksi, "DELETE FROM tarif WHERE kd_tarif='$kode_tarif'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif gagal dihapus...
                                        </div>";
                                }
                            } elseif ($t == 'meter_add'){
                                $username = $_POST['username'];
                                $bulan_sekarang = date('m');
                                $tahun_sekarang = date('Y');
                                $cek_query = mysqli_query($koneksi, "SELECT * FROM pemakaian WHERE username='$username' AND MONTH(tgl)='$bulan_sekarang' AND YEAR(tgl)='$tahun_sekarang'");
                                
                                if(mysqli_num_rows($cek_query) > 0){
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Peringatan!</strong> Data meter untuk warga ini sudah diinput pada bulan ini...
                                    </div>";
                                    echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                } else {
                                    $meter_awal = isset($_POST['meter_awal_hidden']) ? $_POST['meter_awal_hidden'] : $_POST['meter_awal'];
                                    $meter_akhir = $_POST['meter_akhir'];
                                    $kd_tarif = $air->user_to_idtarif($username);
                                    $tarif = $air->kdtarif_to_tarif($kd_tarif);
                                    $pemakaian = $meter_akhir - $meter_awal;
                                    $tagihan = $tarif * $pemakaian;
                                    if($pemakaian < 0){
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter akhir harus lebih besar dari meter awal...
                                        </div>";
                                        echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                    } else {
                                        $status_meter_insert = isset($_POST['status_meter']) ? $_POST['status_meter'] : 'Belum Lunas';
                                        mysqli_query($koneksi, "INSERT INTO pemakaian(username,meter_awal,meter_akhir,pemakaian,tgl,waktu,kd_tarif,tagihan,status) VALUES ('$username','$meter_awal','$meter_akhir','$pemakaian',current_date(),current_time(),'$kd_tarif','$tagihan','$status_meter_insert')");
                                        if(mysqli_affected_rows($koneksi) > 0){
                                            echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                            <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                            <strong>Data</strong> meter berhasil ditambahkan...
                                            </div>";
                                        } else {
                                            echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                            <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                            <strong>Data</strong> meter gagal ditambahkan...
                                            </div>";
                                        }
                                    }
                                }
                            } elseif($t == "meter_edit"){
                                $no = $_POST['no'];
                                $meter_awal = isset($_POST['meter_awal_hidden']) ? $_POST['meter_awal_hidden'] : $_POST['meter_awal'];
                                $meter_akhir = $_POST['meter_akhir'];
                                $username = $air->no_to_username($no);
                                $kd_tarif = $air->user_to_idtarif($username);
                                $tarif = $air->kdtarif_to_tarif($kd_tarif);
                                $pemakaian = $meter_akhir - $meter_awal;
                                $tagihan = $tarif * $pemakaian;
                                if($pemakaian < 0){
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> meter akhir harus lebih besar dari meter awal...
                                    </div>";
                                    echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                } else {
                                    if(isset($_POST['status_meter'])){
                                        $status_meter_update = $_POST['status_meter'];
                                        mysqli_query($koneksi, "UPDATE pemakaian SET meter_awal='$meter_awal', meter_akhir='$meter_akhir', pemakaian='$pemakaian', tagihan='$tagihan', status='$status_meter_update' WHERE no='$no'");
                                    } else {
                                        mysqli_query($koneksi, "UPDATE pemakaian SET meter_awal='$meter_awal', meter_akhir='$meter_akhir', pemakaian='$pemakaian', tagihan='$tagihan' WHERE no='$no'");
                                    }
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter berhasil diubah...
                                        </div>";
                                        echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=masukkan-data-meter-pemakaian-air'; }, 1500);</script>";
                                    } else {
                                        echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter tidak ada perubahan..
                                        </div>";
                                        echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=masukkan-data-meter-pemakaian-air'; }, 1500);</script>";
                                    }
                                }
                            } elseif ($t =="meter_hapus"){
                                $no = $_POST['no'];
                                mysqli_query($koneksi, "DELETE FROM pemakaian WHERE no='$no'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter gagal dihapus...
                                        </div>";
                                }
                            }
                        } elseif (isset($_GET['p'])) {
                            $p = $_GET['p'];
                            if ($p == 'user_edit') {
                                $user = $_GET['user'];
                                $qc = mysqli_query($koneksi, "SELECT password,nama,alamat,kota,tlp,level,tipe,status FROM login WHERE username='$user'");
                                $dc = mysqli_fetch_row($qc);
                                $pass2 = '';
                                $nama = $dc[1];
                                $alamat = $dc[2];
                                $kota = $dc[3];
                                $tlp = $dc[4];
                                $level = $dc[5];
                                $tipe = $dc[6];
                                $status = $dc[7];
                            } elseif ($p == 'tarif_edit') {
                                $kode_tarif = $_GET['kode_tarif'];
                                $qc = mysqli_query($koneksi, "SELECT tarif,tipe,status FROM tarif WHERE kd_tarif='$kode_tarif'");
                                $dc = mysqli_fetch_row($qc);
                                $tarif = $dc[0];
                                $tipe = $dc[1];
                                $status = $dc[2];
                            } elseif ($p == 'meter_edit') {
                                $no = $_GET['no'];
                                $qc = mysqli_query($koneksi, "SELECT username,meter_awal,meter_akhir,pemakaian,status FROM pemakaian WHERE no='$no'");
                                $dc = mysqli_fetch_row($qc);
                                $username = $dc[0];
                                $meter_awal = $dc[1];
                                $meter_akhir = $dc[2];
                                $pemakaian = $dc[3];
                                $status_meter = $dc[4];
                            }
                        }
                        ?>
                        <div class="modal" id="myModal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Konfirmasi hapus data</h4>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="modal-footer">
                                    <form method="post">
                                        <button type="submit" name="tombol" value="/" class="btn btn-danger"  data-bs-dismiss="modal">Ya</button>
                                    </form>
                                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Tidak</button>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-4" id ="user_add">
                            <div class="card-header">
                                <i class="fa-solid fa-user-plus fa-beat"></i>
                                User
                            </div>
                            <div class="card-body">
                                <form method="post" class="needs-validation" id="form_user">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="username" class="form-label">Username: <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="username" placeholder="Masukkan username" name="user" value="<?php echo $user ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="password" class="form-label">Password: <?php if (!isset($_GET['p']) || $_GET['p'] != 'user_edit') echo '<span class="text-danger">*</span>'; ?></label>
                                            <input type="password" class="form-control" id="password" placeholder="Masukkan password" name="password" value="<?php echo $pass2 ?>" <?php if (!isset($_GET['p']) || $_GET['p'] != 'user_edit') echo 'required'; ?>>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nama" class="form-label">Nama: <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="nama" placeholder="Masukkan nama" name="nama" value="<?php echo $nama ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="tlp" class="form-label">No. Telepon:</label>
                                            <input type="text" class="form-control" id="tlp" placeholder="Masukkan telepon" name="tlp" value="<?php echo $tlp ?>">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat" class="form-label">Alamat:</label>
                                        <textarea class="form-control" rows="3" id="alamat" name="alamat"><?php echo $alamat ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="kota" class="form-label">Kota:</label>
                                            <input type="text" class="form-control" id="kota" placeholder="Masukkan kota" name="kota" value="<?php echo $kota ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="status" class="form-label">Status: <span class="text-danger">*</span></label>
                                            <div class="d-flex align-items-center h-100 pb-4">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <?php
                                                    $st = array('Aktif', 'Non-Aktif');
                                                    foreach ($st as $st2) {
                                                        $checked = ($status == $st2 || (empty($status) && $st2 == 'Aktif')) ? 'checked' : '';
                                                        echo "<div class='form-check form-check-inline mb-0'>";
                                                        echo "<input class='form-check-input' type='radio' name='status' id='status_$st2' value='$st2' $checked required>";
                                                        echo "<label class='form-check-label' for='status_$st2'>" . ucwords($st2) . "</label>";
                                                        echo "</div>";
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="level" class="form-label">Level: <span class="text-danger">*</span></label>
                                            <div class="d-flex align-items-center h-100 pb-4">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <?php
                                                    $lv = array(
                                                        'Admin' => 'fa-user-shield text-danger fa-shake',
                                                        'Bendahara' => 'fa-wallet text-warning fa-beat',
                                                        'Warga' => 'fa-house-user text-success fa-fade',
                                                        'Petugas' => 'fa-user-tie text-primary fa-bounce'
                                                    );
                                                    foreach ($lv as $lv2 => $icon) {
                                                        $checked = ($level == $lv2 || (empty($level) && $lv2 == 'Warga')) ? 'checked' : '';
                                                        echo "<div class='form-check form-check-inline mb-0'>";
                                                        echo "<input class='form-check-input' type='radio' name='level' id='level_$lv2' value='$lv2' $checked required>";
                                                        echo "<label class='form-check-label' for='level_$lv2'><i class='fas $icon me-1'></i>" . ucwords($lv2) . "</label>";
                                                        echo "</div>";
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="tipe" class="form-label">Tipe: <span class="text-danger">*</span></label>
                                            <div class="d-flex align-items-center h-100 pb-4">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <?php
                                                    $t = array(
                                                        'RT' => 'fa-house text-info',
                                                        'Kos' => 'fa-bed text-secondary'
                                                    );
                                                    foreach ($t as $t2 => $icon) {
                                                        $checked = ($tipe == $t2 || (empty($tipe) && $t2 == 'RT')) ? 'checked' : '';
                                                        echo "<div class='form-check form-check-inline mb-0'>";
                                                        echo "<input class='form-check-input' type='radio' name='tipe' id='tipe_$t2' value='$t2' $checked required>";
                                                        echo "<label class='form-check-label' for='tipe_$t2'><i class='fas $icon me-1'></i>" . ucwords($t2) . "</label>";
                                                        echo "</div>";
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary" name="tombol" value="user_add">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <div class="card mb-4" id ="tarif_add">
                            <div class="card-header">
                                <i class="fa-solid fa-money-bill-wave fa-beat-fade"></i>
                                Data Tarif
                            </div>
                            <div class="card-body">
                                <form method="post" class="needs-validation" id="form_tarif">
                                    <div class="mb-3">
                                        <label for="kode_tarif" class="form-label">Kode Tarif:</label>
                                        <input type="text" class="form-control" id="kode_tarif" placeholder="Masukkan kode tarif" name="kode_tarif" value="<?php echo $kode_tarif ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tarif" class="form-label">Tarif:</label>
                                        <input type="number" class="form-control" id="tarif" placeholder="Masukkan tarif" name="tarif" value="<?php echo $tarif ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipe" class="form-label">Tipe:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $t = array(
                                                'RT' => 'fa-house text-info',
                                                'Kos' => 'fa-bed text-secondary'
                                            );
                                            foreach ($t as $t2 => $icon) {
                                                $checked = ($tipe == $t2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='tipe' id='tipe_$t2' value='$t2' $checked>";
                                                echo "<label class='form-check-label' for='tipe_$t2'><i class='fas $icon me-1'></i>" . ucwords($t2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $st = array('Aktif', 'Non-Aktif');
                                            foreach ($st as $st2) {
                                                $checked = ($status == $st2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='status' id='status_$st2' value='$st2' $checked>";
                                                echo "<label class='form-check-label' for='status_$st2'>" . ucwords($st2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary" name="tombol" value="tarif_add">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <?php if ($user_level != 'Bendahara' || ($user_level == 'Bendahara' && $e[1] == "meter_edit&no")) { ?>
                        <div class="card mb-4" id ="meter_add">
                            <div class="card-header">
                                <i class="fa-solid fa-faucet-drip fa-fade"></i>
                                Data Meter
                            </div>
                            <div class="card-body">
                                <?php
                                if ($e[1] == "meter_edit&no") {
                                    $disable = 'disabled';
                                    $readonly_bendahara = ($user_level == 'Bendahara') ? 'readonly' : '';
                                } else {
                                    $disable = '';
                                    $readonly_bendahara = '';
                                    $status_meter = '';
                                }
                                ?>
                                <form method="post" class="needs-validation" id="form_meter">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Nama Warga:</label>
                                        <select class="form-select" name="username" required <?php echo $disable ?>>
                                            <option value="">Nama Warga </option>
                                            <?php
                                            $q = mysqli_query($koneksi, "SELECT username, nama FROM login WHERE level='Warga' ORDER BY nama ASC");
                                            while ($d = mysqli_fetch_row($q)) {
                                                if ($username == $d[0]) $selected = 'selected';
                                                else $selected = '';
                                                echo "<option value='$d[0]' $selected>$d[1]</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="meter_awal" class="form-label">Meter Awal (m<sup>3</sup>):</label>
                                        <input type="text" class="form-control" id="meter_awal" placeholder="Masukkan meter awal " name="meter_awal" value="<?php echo $meter_awal ?>" required disabled>
                                    </div>
                                    <div class="mb-3">
                                        <label for="meter_akhir" class="form-label">Meter Akhir (m<sup>3</sup>):</label>
                                        <input type="number" class="form-control" id="meter_akhir" placeholder="Masukkan meter akhir " name="meter_akhir" value="<?php echo $meter_akhir ?>" required <?php echo $readonly_bendahara; ?>>
                                    </div>
                                    <?php if ($user_level == 'Admin' || ($user_level == 'Bendahara' && $e[1] == "meter_edit&no")) { ?>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status:</label>
                                        <div class="d-flex gap-3 mt-1">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="status_meter" id="status_lunas" value="Lunas" <?php if($status_meter=='Lunas') echo 'checked'; ?> required>
                                                <label class="form-check-label" for="status_lunas">LUNAS</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="status_meter" id="status_blm_lunas" value="Belum Lunas" <?php if($status_meter=='Belum Lunas' || $status_meter=='') echo 'checked'; ?> required>
                                                <label class="form-check-label" for="status_blm_lunas">BELUM LUNAS</label>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <input type="hidden" name="meter_awal_hidden" value="<?php echo $meter_awal ?>">
                                    <?php if($e[1] == "meter_edit&no") { 
                                        echo "<input type='hidden' name='no' value='$no'>";
                                    } ?>
                                    <button type="submit" class="btn btn-primary" name="tombol" value="<?php echo ($e[1] == "meter_edit&no") ? 'meter_edit' : 'meter_add'; ?>">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <?php } ?>
                        <div class="card mb-4" id ="user_list">
                            <div class="card-header">
                                <i class="fa-solid fa-users-gear fa-flip"></i>
                                Data User
                            </div>
                            <div class="card-body table-responsive">
                                <table id="datatablesSimple" class="table table-sm table-striped table-hover align-middle text-center">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>Nama</th>
                                            <th>Alamat</th>
                                            <th>Kota</th>
                                            <th>Telephone</th>
                                            <th>Level</th>
                                            <th>Tipe</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT username,nama,alamat,kota,tlp,level,tipe,status FROM login ORDER BY level ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $user = $d[0];
                                            $nama = $d[1];
                                            $alamat = $d[2];
                                            $kota = $d[3];
                                            $tlp = $d[4];
                                            $level = $d[5];
                                            $tipe = $d[6];
                                            $status = $d[7];
                                            echo "<tr>
                                                    <td>$user</td>
                                                    <td>$nama</td>
                                                    <td>$alamat</td>
                                                    <td>$kota</td>
                                                    <td>$tlp</td>
                                                    <td>$level</td>
                                                    <td>$tipe</td>
                                                    <td>$status</td>
                                                    <td>
                                                        <div class='d-flex flex-nowrap gap-1 justify-content-center'>
                                                            <a href=index.php?p=user_edit&user=$user><button type=button class='btn btn-outline-primary'><i class='fas fa-pen-to-square me-1'></i> Ubah</button></a>
                                                            <button type=button class='btn btn-outline-danger' data-bs-toggle=modal data-bs-target=#myModal data-user=$user><i class='fas fa-trash me-1'></i> Hapus</button>
                                                        </div>
                                                    </td>
                                                </tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id ="tarif_list">
                            <div class="card-header">
                                <i class="fa-solid fa-money-bill-wave fa-beat-fade"></i>
                                Data Tarif
                            </div>
                            <div class="card-body table-responsive">
                                <table id="tarif_table" class="table table-sm table-striped table-hover align-middle text-center">
                                    <thead>
                                        <tr>
                                            <th>Kode Tarif</th>
                                            <th>Tarif</th>
                                            <th>Tipe</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT kd_tarif,tarif,tipe,status FROM tarif ORDER BY kd_tarif ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $kode_tarif = $d[0];
                                            $tarif = $d[1];
                                            $tipe = $d[2];
                                            $status = $d[3];
                                            echo "<tr>
                                                    <td>$kode_tarif</td>
                                                    <td>$tarif</td>
                                                    <td>$tipe</td>
                                                    <td>$status</td>
                                                    <td class='text-center align-middle action-cell'>
                                                        <div class='action-wrap'>
                                                            <a href=index.php?p=tarif_edit&kode_tarif=$kode_tarif><button type=button class='btn btn-outline-primary'><i class='fas fa-pen-to-square me-1'></i>Ubah</button></a>
                                                            <button type=button class='btn btn-outline-danger' data-bs-toggle=modal data-bs-target=#myModal data-tarif=$kode_tarif><i class='fas fa-trash me-1'></i>Hapus</button>
                                                        </div>
                                                    </td>
                                                </tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id ="meter_list">
                            <div class="card-header">
                                <i class="fa-solid fa-faucet-drip fa-fade"></i>
                                Data Meter Warga
                            </div>
                            <div class="card-body table-responsive">
                                <table id="meter_table" class="table table-sm table-striped table-hover align-middle text-center">
                                    <thead>
                                        <tr>
                                            <th class="text-center align-middle">Nama Warga</th>
                                            <th class="text-center align-middle">Tipe</th>
                                            <th class="text-center align-middle">Tanggal & Waktu</th>
                                            <th class="text-center align-middle">Meter Awal (m<sup>3</sup>)</th>
                                            <th class="text-center align-middle">Meter Akhir (m<sup>3</sup>)</th>
                                            <th class="text-center align-middle">Pemakaian (m<sup>3</sup>)</th>
                                            <?php if ($user_level == 'Bendahara' || $user_level == 'Admin') { ?>
                                            <th class="text-center align-middle">Tagihan (Rp)</th>
                                            <th class="text-center align-middle">Status</th>
                                            <?php } ?>
                                            <th class="text-center align-middle">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT no,username,meter_awal,meter_akhir,pemakaian,tgl,waktu,tagihan,status FROM pemakaian ORDER BY tgl DESC, username ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $no = $d[0];
                                            $dt_user2 = $air->dt_user($d[1]);
                                            $nama = $dt_user2[0];
                                            $tipe_warga = $dt_user2[3];
                                            $meter_awal = $d[2];
                                            $meter_akhir = $d[3];
                                            $pemakaian = $d[4];
                                            $tgl = $air->tgl_walik($d[5]);
                                            $waktu = $d[6];
                                            $tagihan = $d[7];
                                            $status_tagihan = $d[8];
                                            $level_login = $dt_user[2];
                                            $tgl_meter = date_create($d[5]);
                                            $tgl_sekarang = date_create();
                                            $diff = date_diff($tgl_meter, $tgl_sekarang);
                                            $selisih =$diff->days;
                                            $indo = [
                                                'Monday'=>'Senin', 'Tuesday'=>'Selasa', 'Wednesday'=>'Rabu', 'Thursday'=>'Kamis', 
                                                'Friday'=>'Jumat', 'Saturday'=>'Sabtu', 'Sunday'=>'Minggu',
                                                'January'=>'Januari', 'February'=>'Februari', 'March'=>'Maret', 'April'=>'April', 
                                                'May'=>'Mei', 'June'=>'Juni', 'July'=>'Juli', 'August'=>'Agustus', 
                                                'September'=>'September', 'October'=>'Oktober', 'November'=>'November', 'December'=>'Desember'
                                            ];
                                            $tgl_tampil = strtr(date("d F Y", strtotime($tgl)), $indo);
                                            $hari_ini   = strtr(date("d F Y", strtotime(date("Y-m-d"))), $indo);
                                            $tagihan_rp = "Rp " . number_format($tagihan, 0, ',', '.');

                                            echo "<tr>
                                                    <td class='text-center align-middle'>$nama</td>
                                                    <td class='text-center align-middle'>$tipe_warga</td>
                                                    <td class='text-center align-middle'>
                                                        <div class='date-stack'>
                                                            <div class='date-stack__day'>$tgl_tampil</div>
                                                            <div class='date-stack__time'>$waktu</div>
                                                            <div class='date-stack__ago'>$selisih hari lalu</div>
                                                        </div>
                                                    </td> 
                                                    <td class='text-center align-middle'>$meter_awal</td>
                                                    <td class='text-center align-middle'>$meter_akhir</td>
                                                    <td class='text-center align-middle'>$pemakaian</td>";
                                                    
                                            if ($user_level == 'Bendahara' || $user_level == 'Admin') {
                                                        $badge_class = (strtolower($status_tagihan) == 'lunas') ? 'status-pill status-pill--success' : 'status-pill status-pill--danger';
                                                        $badge_icon = (strtolower($status_tagihan) == 'lunas') ? 'fa-circle-check' : 'fa-triangle-exclamation';
                                                $status_display = strtoupper($status_tagihan);
                                                echo "<td class='text-center align-middle fw-bold'>$tagihan_rp</td>
                                                              <td class='text-center align-middle'><span class='$badge_class'><i class='fas $badge_icon'></i><span>$status_display</span></span></td>";
                                            }
                                            if ($level_login == 'Admin' || $level_login == 'Bendahara'){
                                                echo "<td class='text-center align-middle'>
                                                        <div class='d-flex flex-nowrap gap-1 justify-content-center'>
                                                            <a href='index.php?p=meter_edit&no=$no' class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></a>
                                                            <button type='button' class='btn btn-outline-danger' data-bs-toggle='modal' data-bs-target='#myModal' data-no='$no'><i class='fas fa-trash'></i></button>
                                                        </div>
                                                    </td>";

                                            } else{
                                                if($selisih <=30){
                                                    echo "<td class='text-center align-middle'>
                                                            <div class='d-flex flex-nowrap gap-1 justify-content-center'>
                                                                <a href='index.php?p=meter_edit&no=$no' class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></a>
                                                                <button type='button' class='btn btn-outline-danger' data-bs-toggle='modal' data-bs-target='#myModal' data-no='$no'><i class='fas fa-trash'></i></button>
                                                            </div>
                                                        </td>";
                                                } else {
                                                    echo "<td></td>";
                                                }
                                            }
                                             echo "</tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id="pemakaian_sendiri_list" style="display: none;">
                            <div class="card-header">
                                <i class="fas fa-receipt fa-fade"></i>
                                Data Pemakaian dan Pembayaran
                            </div>
                            <div class="card-body table-responsive">
                                <table id="pemakaian_sendiri_table" class="table table-sm table-striped table-hover align-middle text-center">
                                    <thead>
                                        <tr>
                                            <th class="text-center align-middle">Waktu Pencatatan Meter</th>
                                            <th class="text-center align-middle">Kode Tarif</th>
                                            <th class="text-center align-middle">Meter Awal (m<sup>3</sup>)</th>
                                            <th class="text-center align-middle">Meter Akhir (m<sup>3</sup>)</th>
                                            <th class="text-center align-middle">Pemakaian (m<sup>3</sup>)</th>
                                            <th class="text-center align-middle">Tagihan (Rp)</th>
                                            <th class="text-center align-middle">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (isset($_SESSION['user'])) {
                                            $user_login = $_SESSION['user'];
                                            $q_pemakaian = mysqli_query($koneksi,"SELECT tgl, waktu, kd_tarif, meter_awal, meter_akhir, pemakaian, tagihan, status FROM pemakaian WHERE username='$user_login' ORDER BY tgl DESC");
                                            while($dp = mysqli_fetch_row($q_pemakaian)){
                                                $tgl = $air->tgl_walik($dp[0]);
                                                $waktu = $dp[1];
                                                $kd_tarif = $dp[2];
                                                $meter_awal = $dp[3];
                                                $meter_akhir = $dp[4];
                                                $pemakaian = $dp[5];
                                                $tagihan = $dp[6];
                                                $status_tagihan = $dp[7];
                                                $badge_color = (strtolower($status_tagihan) == 'lunas') ? 'bg-success' : 'bg-danger';
                                                $status_display = strtoupper($status_tagihan);
                                                $indo = [
                                                'Monday'=>'Senin', 'Tuesday'=>'Selasa', 'Wednesday'=>'Rabu', 'Thursday'=>'Kamis', 
                                                'Friday'=>'Jumat', 'Saturday'=>'Sabtu', 'Sunday'=>'Minggu',
                                                'January'=>'Januari', 'February'=>'Februari', 'March'=>'Maret', 'April'=>'April', 
                                                'May'=>'Mei', 'June'=>'Juni', 'July'=>'Juli', 'August'=>'Agustus', 
                                                'September'=>'September', 'October'=>'Oktober', 'November'=>'November', 'December'=>'Desember'
                                                ];
                                                $tgl_tampil = strtr(date("d F Y", strtotime($tgl)), $indo);
                                                $tgl_meter = date_create($dp[0]);
                                                $tgl_sekarang = date_create();
                                                $diff = date_diff($tgl_meter, $tgl_sekarang);
                                                $selisih =$diff->days;
                                                $hari_ini = strtr(date("d F Y", strtotime(date("Y-m-d"))), $indo);
                                                $tagihan_rp = "Rp " . number_format($tagihan, 0, ',', '.');
                                                $badge_class = (strtolower($status_tagihan) == 'lunas') ? 'status-pill status-pill--success' : 'status-pill status-pill--danger';
                                                $badge_icon = (strtolower($status_tagihan) == 'lunas') ? 'fa-circle-check' : 'fa-triangle-exclamation';
                                                $status_display = strtoupper($status_tagihan);
                                                
                                                echo "<tr>
                                                        <td class='text-center align-middle'>
                                                            <div class='date-stack'>
                                                                <div class='date-stack__day'>$tgl_tampil</div>
                                                                <div class='date-stack__time'>$waktu</div>
                                                                <div class='date-stack__ago'>$selisih hari lalu</div>
                                                            </div>
                                                        </td>
                                                        <td class='text-center align-middle'>$kd_tarif</td>
                                                        <td class='text-center align-middle'>$meter_awal</td>
                                                        <td class='text-center align-middle'>$meter_akhir</td>
                                                        <td class='text-center align-middle'>$pemakaian</td>
                                                        <td class='text-center align-middle fw-bold'>$tagihan_rp</td>
                                                        <td class='text-center align-middle'><span class='$badge_class'><i class='fas $badge_icon'></i><span>$status_display</span></span></td>
                                                    </tr>";
                                            }
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Sistem Informasi Manajemen Air <?php echo date('Y'); ?></div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/chart-area-demo.js"></script>
        <script src="../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
