<?php
session_start();
include '../assets/func.php';
$air=new klas_air();
$koneksi=$air->koneksi();
if (isset($_POST['p'])) {
    $p= $_POST['p'];
    if($p == "summary"){
        $bln = isset($_POST['t']) ? $_POST['t'] : date('Y-m');
        if (!preg_match('/^\d{4}-\d{2}$/', $bln)) {
            $bln = date('Y-m');
        }
        $level = isset($_POST['level']) ? $_POST['level'] : '';

        if ($level == 'Warga') {
            $username = $_SESSION['user'];
            $q = mysqli_query($koneksi, "SELECT tgl, waktu, pemakaian, tagihan, status FROM pemakaian WHERE username='$username' AND tgl like '$bln%' LIMIT 1");
            if ($d = mysqli_fetch_assoc($q)) {
                $tanggal = (int)date('d', strtotime($d['tgl']));
                $data[] = array(
                    'tgl' => $tanggal,
                    'waktu' => $d['waktu'],
                    'pemakaian' => $d['pemakaian'],
                    'tagihan' => $d['tagihan'],
                    'status' => $d['status']
                );
            } else {
                $data[] = array(
                    'tgl' => '-',
                    'waktu' => '-',
                    'pemakaian' => 0,
                    'tagihan' => 0,
                    'status' => 'Belum Ada Data'
                );
            }
        } else {
            $ql = mysqli_query($koneksi, "SELECT COUNT(username) as jml_pelanggan FROM login WHERE level='Warga'");
            $dl = mysqli_fetch_assoc($ql);
            $data[]= array('pelanggan' => $dl['jml_pelanggan']);

            if ($level == 'Bendahara') {
                $q2 = mysqli_query($koneksi, "SELECT COALESCE(SUM(tagihan), 0) as jml_pemasukan FROM pemakaian WHERE tgl like '$bln%' AND status='Lunas'");
                $d2 = mysqli_fetch_assoc($q2);
                $data[]= array('pemasukan' => $d2['jml_pemasukan']);

                $q3 = mysqli_query($koneksi, "SELECT COUNT(DISTINCT username) as sdh_lunas FROM pemakaian WHERE tgl like '$bln%' AND status='Lunas'");
                $d3 = mysqli_fetch_assoc($q3);
                $data[]= array('lunas' => $d3['sdh_lunas']);
            } else {
                $q2 = mysqli_query($koneksi, "SELECT COALESCE(SUM(pemakaian), 0) as jml_pemakaian FROM pemakaian WHERE tgl like '$bln%'");
                $d2 = mysqli_fetch_assoc($q2);
                $data[]= array('pemakaian' => $d2['jml_pemakaian']);
                
                $q3 = mysqli_query($koneksi, "SELECT COUNT(username) as sdh_dicatat FROM pemakaian WHERE tgl like '$bln%'");
                $d3 = mysqli_fetch_assoc($q3);
                $data[]= array('tercatat' => $d3['sdh_dicatat']);
            }
        }
        echo json_encode($data);
    }
}
