$(document).ready(function() {
    uri = window.location.href;
    e = uri.split("=");
    console.log("URI: " + uri + " e[1]: " + e[1]);

    if (e[1] === "manajemen-data-user" || e[1] === "user_edit&user") {
        if(e[1] === "manajemen-data-user"){
            $("#summary,#chart,#user_add,#tarif_add,#tarif_list,#meter_add,#meter_list").hide();
        }else {
            $("#summary,#chart,#user_list,#tarif_add,#tarif_list,#meter_add,#meter_list").hide();
            $("#user_add").show();
            $("#form_user button").val("user_edit");
            $("#form_user input[name='user']").attr("disabled", true);
            $("#form_user").append("<input type='hidden' name='user' value='" + e[2] + "'>");
        }
        $(".datatable-dropdown").prepend("<button type='button' class='btn btn-outline-primary float-start me-2'><i class='fas fa-user-plus'></i> <span class='text-dark'>User</span></button>");
        $(".datatable-dropdown button").click(function() {
            $("#user_add").show();
            $("#user_list").hide();
            $("#form_user input[type='text'], #form_user input[type='password'], #form_user input[type='number'], #form_user textarea").val("");
            $("#form_user input[type='radio']").prop("checked", false);
        });
        $("button[data-bs-toggle='modal']").click(function() {
            user=$(this).attr('data-user');
            $("#myModal .modal-body").text("Apakah Anda yakin ingin menghapus data user " + user + "?");  
            $(".modal-footer form input[name='user'], .modal-footer form input[name='tarif'], .modal-footer form input[name='kode_tarif']").remove();
            $(".modal-footer form").append("<input type='hidden' name='user' value='" + user + "'>");
            $(".modal-footer form button[name='tombol']").val("user_hapus");
        });
    } else if (e[1] === "manajemen-data-tarif-air" || e[1] === "tarif_edit&kode_tarif") {
        if(e[1] === "manajemen-data-tarif-air"){
            $("#summary,#chart,#tarif_add,#user_add,#user_list,#meter_add,#meter_list").hide();
        }else {
            $("#summary,#chart,#tarif_list,#user_add,#user_list,#meter_add,#meter_list").hide();
            $("#tarif_add").show();
            $("#form_tarif button").val("tarif_edit");
            $("#form_tarif input[name='kode_tarif']").attr("disabled", true);
            $("#form_tarif").append("<input type='hidden' name='kode_tarif' value='" + e[2] + "'>");
        }
        const datatablesSimple = document.getElementById('tarif_table');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }       
        $(".datatable-dropdown").prepend("<button type=button class='btn btn-outline-success float-start me-2'><i class='fas fa-money-bill'></i> <span class='text-dark'>Tarif</span></button>");
        $(".datatable-dropdown button").click(function() {
            $("#tarif_add").show();
            $("#tarif_list").hide();
            $("#form_tarif input[type='text'], #form_tarif input[type='number'], #form_tarif textarea").val("");
            $("#form_tarif input[type='radio']").prop("checked", false);
        });
        $("button[data-bs-toggle='modal']").click(function() {
            kode_tarif=$(this).attr('data-tarif');
            $("#myModal .modal-body").text("Apakah Anda yakin ingin menghapus data tarif " + kode_tarif + "?");  
            $(".modal-footer form input[name='user'], .modal-footer form input[name='tarif'], .modal-footer form input[name='kode_tarif']").remove();
            $(".modal-footer form").append("<input type='hidden' name='kode_tarif' value='" + kode_tarif + "'>");
            $(".modal-footer form button[name='tombol']").val("tarif_hapus");
        });
    } else if (e[1] === "masukkan-data-meter-pemakaian-air" || e[1] == 'meter_edit&no') {
        if(e[1] === "masukkan-data-meter-pemakaian-air"){
            $("#summary,#chart,#tarif_add,#user_add,#user_list,#tarif_list,#meter_add").hide();
        }else {
            $("#summary,#chart,#tarif_list,#user_add,#user_list,#meter_list,#tarif_add").hide();
            $("#meter_add").show();
            $("#form_meter button").val("meter_edit");
            $("#form_meter input[name='no']").attr("disabled", true);
            $("#form_meter").append("<input type='hidden' name='no' value='" + e[2] + "'>");
        }
        const datatablesSimple = document.getElementById('meter_table');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }       
        if (typeof user_level !== 'undefined' && user_level !== 'Bendahara') {
            $(".datatable-dropdown").prepend("<button type=button class='btn btn-outline-warning float-start me-2'><i class='fas fa-tachometer-alt'></i> <span class='text-dark'>Meter</span></button>");
            $(".datatable-dropdown button").click(function() {
                $("#meter_add").show();
                $("#meter_list").hide();
                $("#form_meter input:not([type=radio])").val("");
                $("#form_meter select").val("");
                $("input[name='meter_awal_hidden']").val("");
            });
        }
        $("#form_meter select[name='username']").change(function() {
            var username = $(this).val();
            if(username !== '') {
                $.ajax({
                    url: 'index.php',
                    method: 'POST',
                    data: { username: username, get_last_meter: 1 },
                    dataType: 'json',
                    success: function(response) {
                        $("#meter_awal").val(response.meter_awal);
                        $("input[name='meter_awal_hidden']").val(response.meter_awal);
                    },
                    error: function() {
                        console.log('Error fetching meter data');
                        $("#meter_awal").val('0');
                        $("input[name='meter_awal_hidden']").val('0');
                    }
                });
            }
        });
        $("button[data-bs-toggle='modal']").click(function() {
            no=$(this).attr('data-no');
            $("#myModal .modal-body").text("Apakah Anda yakin ingin menghapus data meter " + no + "?");  
            $(".modal-footer form input[name='user'], .modal-footer form input[name='tarif'], .modal-footer form input[name='kode_tarif']").remove();
            $(".modal-footer form").append("<input type='hidden' name='no' value='" + no + "'>");
            $(".modal-footer form button[name='tombol']").val("meter_hapus");
        });
    } else if (e[1] === "pemakaian_sendiri_list") {
        $("#summary,#chart,#tarif_add,#tarif_list,#user_add,#user_list,#meter_add,#meter_list").hide();
        $("#pemakaian_sendiri_list").show();
        const datatablesSimple = document.getElementById('pemakaian_sendiri_table');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    }else {
        $("#summary,#chart").show();
        $("#pilih_waktu select[name='pilih_waktu']").on('change', function() {
            $bln = $(this).val();
            $.ajax({
                type:"post",
                url:"../assets/ajax.php",
                data:{p:"summary",t:$bln,level:user_level},
                dataType:"json",
            })
            .done(function(d){
                if (typeof user_level !== 'undefined' && user_level === 'Warga') {
                    $("#summary .bg-primary h1").text(d[0].tgl || '-');
                    $("#summary .bg-primary .ms-3").text(d[0].waktu || '-');
                    $("#summary .bg-warning h1").text(d[0].pemakaian || 0);
                    $("#summary .bg-success h1").text(
                        Number(d[0].tagihan || 0).toLocaleString('id-ID')
                    );
                    let status = d[0].status;
                    if (status == 'Belum Ada Data') {
                        status = '-';
                    } else if (status != 'Lunas') {
                        status = 'BELUM LUNAS';
                    }
                    $("#summary .bg-danger h1").text(status);
                } else {
                    var pelanggan = parseInt(d[0].pelanggan || 0, 10);
                    $("#summary .bg-primary h1").text(d[0].pelanggan);
                    if (typeof user_level !== 'undefined' && user_level === 'Bendahara') {
                        var lunas = parseInt(d[2].lunas || 0, 10);
                        var belum_bayar = pelanggan - lunas;
                        $("#summary .bg-warning h1").text(
                            Number(d[1].pemasukan || 0).toLocaleString('id-ID')
                        );
                        $("#summary .bg-success h1").text(lunas);
                        $("#summary .bg-danger h1").text(belum_bayar);
                    } else {
                        var tercatat = parseInt(d[2].tercatat || 0, 10);
                        var blm_dicatat = pelanggan - tercatat;
                        $("#summary .bg-warning h1").text(d[1].pemakaian || 0);
                        $("#summary .bg-success h1").text(tercatat);
                        $("#summary .bg-danger h1").text(blm_dicatat);
                    }
                }
            })
            .fail(function(){

            })
        });
        if (!$("#pilih_waktu select[name='pilih_waktu']").val()) {
            var today = new Date();
            var month = String(today.getMonth() + 1).padStart(2, '0');
            $("#pilih_waktu select[name='pilih_waktu']").val(today.getFullYear() + "-" + month);
        }
        $("#pilih_waktu select[name='pilih_waktu']").trigger("change");
        $("#tarif_add,#tarif_list,#user_add,#user_list,#meter_add,#meter_list,#pemakaian_sendiri_list").hide();
    }
})
