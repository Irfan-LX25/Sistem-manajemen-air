<?php
session_start();
if(empty($_SESSION['user']) && empty($_SESSION['pass'])){
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// koneksi ke database MySQL
include '../assets/func.php';
$air = new klas_air();
$koneksi = $air->koneksi();

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])){
    $username = $_POST['username'];
    
    // Ambil meter_akhir terakhir dari warga tersebut
    $q = mysqli_query($koneksi, "SELECT meter_akhir FROM pemakaian WHERE username='$username' ORDER BY tgl DESC, no DESC LIMIT 1");
    
    if($q && mysqli_num_rows($q) > 0){
        $d = mysqli_fetch_row($q);
        $meter_terakhir = $d[0];
    } else {
        $meter_terakhir = 0; // Jika belum pernah ada meter sebelumnya
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode(['meter_awal' => $meter_terakhir]);
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Bad request']);
}
?>
