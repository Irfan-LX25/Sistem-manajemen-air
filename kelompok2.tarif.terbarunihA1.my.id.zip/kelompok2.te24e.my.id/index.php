<?php
// koneksi ke database MySQL
include './assets/func.php';
$air=new klas_air();
$koneksi=$air->koneksi();

// $pass = password_hash("petugas",PASSWORD_DEFAULT);
// mysqli_query($koneksi,"INSERT INTO login(username,password,nama,alamat,kota,tlp,level,tipe,status) VALUES ('petugas','$pass','Petugas','Polines','Semarang','024111','Petugas','-','AKTIF')");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login - Kelompok2</title>
        <link rel="icon" href="/assets/img/polines.png"> 
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container"> 
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Login</h3></div>
                                    <div class="card-body">
                                         <?php
                                            if(isset($_POST['tombol'])){
                                                session_start();
                                                $username = $_POST['username'];
                                                $password = $_POST['password'];

                                                $qc = mysqli_query($koneksi, "SELECT username, password FROM login WHERE username='$username'");
                                                $dc = mysqli_fetch_row($qc);

                                                if (!empty($dc[0])) $user_cek = $dc[0];

                                                if (!empty($user_cek)){
                                                    $pass_cek = $dc[1];
                                                    if (password_verify($password, $pass_cek)){
                                                        $_SESSION['user'] = $username;
                                                        $_SESSION['pass'] = $password;
                                                        echo"<script>window.location.replace('./login/index.php');</script>";
                                                    } else {
                                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                                    <strong>Login</strong> tidak berhasil, pastikan username dan password benar...
                                                    </div>";
                                                    }
                                                } else {
                                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                                    <strong>Username</strong> tidak ketemu...
                                                    </div>";
                                                }
                                            }
                                        ?>
                                        <form method="post" class="needs-validation">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputUser" type="text" placeholder="Username" name="username" required />
                                                <label for="inputUser">Username</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputPassword" type="password" placeholder="Password" name="password" required />
                                                <label for="inputPassword">Password</label>
                                            </div>
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" id="inputRememberPassword" type="checkbox" value="" />
                                                <label class="form-check-label" for="inputRememberPassword">Remember Password</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="small" href="password.html">Forgot Password?</a>
                                                <input class="btn btn-primary" type="submit" name="tombol" value="Login" />
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <div class="small"><a href="register.html">Need an account? Sign up!</a></div>
                                        <div style="margin-top: 15px;">
                                            <a href="profile_developer.php" id="btnMeetDevs" style="
                                                display: inline-block;
                                                padding: 10px 28px;
                                                background: linear-gradient(135deg, #89CFF0, #5DADE2);
                                                color: #fff;
                                                font-weight: 600;
                                                font-size: 0.95rem;
                                                border: none;
                                                border-radius: 20px;
                                                text-decoration: none;
                                                box-shadow: 0 4px 15px rgba(93, 173, 226, 0.35);
                                                transition: all 0.3s ease;
                                                letter-spacing: 0.3px;
                                            " onmouseover="this.style.transform='scale(1.06)';this.style.boxShadow='0 6px 25px rgba(93,173,226,0.55)';" onmouseout="this.style.transform='scale(1)';this.style.boxShadow='0 4px 15px rgba(93,173,226,0.35)';">Touch The Developers</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; kelompok 2 2026</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
