$(document).ready(function() {
    // console.log("jquery ready");
    uri = window.location.href;
    e = uri.split("=");
    console.log("URI: " + uri + " e[1]: " + e[1]);

    if (e[1] === "manajemen-data-user" || e[1] === "user_edit&user") {
        // $("#summary,#chart,#user_add,#tarif_add,#tarif_list").hide();
        if(e[1] === "manajemen-data-user"){
            // id summary, chart disembunyikan
            $("#summary,#chart,#user_add,#tarif_add,#tarif_list").hide();
        }else {
            $("#summary,#chart,#user_list,#tarif_add,#tarif_list").hide();
            $("#user_add").show();
            // reset tombol user_add jadi user_edit
            $("#form_user button").val("user_edit");
            //mendisable input username
            $("#form_user input[name='user']").attr("disabled", true);
            //menambahkan elemen input hidden untuk menyimpan username yang diedit
            $("#form_user").append("<input type='hidden' name='user' value='" + e[2] + "'>");
        }
        // menyisipkan tombol user pada dropdown
        $(".datatable-dropdown").append("<button type='button' class='btn btn-outline-success float-start me-2'><i class='fas fa-user-plus'></i> User</button>");
        // membuat tombol user dapat diklik
        $(".datatable-dropdown button").click(function() {
           // console.log("tombol user diklik");
            $("#user_add").show();
            $("#user_list").hide();
            $("#form_user input[type='text'], #form_user input[type='password'], #form_user input[type='number'], #form_user textarea").val("");
            $("#form_user input[type='radio']").prop("checked", false);
        });
        //membuat konfirmasi hapus data user
        $("button[data-bs-toggle='modal']").click(function() {
            user=$(this).attr('data-user');
            $("#myModal .modal-body").text("Apakah Anda yakin ingin menghapus data user " + user + "?");  
            $(".modal-footer form input[name='user'], .modal-footer form input[name='tarif'], .modal-footer form input[name='kode_tarif']").remove();
            $(".modal-footer form").append("<input type='hidden' name='user' value='" + user + "'>");
            $(".modal-footer form button[name='tombol']").val("user_hapus");
        });
    } else if (e[1] === "manajemen-data-tarif-air" || e[1] === "tarif_edit&kode_tarif") {
        // $("#summary,#chart,#tarif_add,#user_add,#user_list").hide();
        if(e[1] === "manajemen-data-tarif-air"){
            // id summary, chart disembunyikan
            $("#summary,#chart,#tarif_add,#user_add,#user_list").hide();
        }else {
            $("#summary,#chart,#tarif_list,#user_add,#user_list").hide();
            $("#tarif_add").show();
            // reset tombol tarif_add jadi tarif_edit
            $("#form_tarif button").val("tarif_edit");
            //mendisable input kode_tarif
            $("#form_tarif input[name='kode_tarif']").attr("disabled", true);
            //menambahkan elemen input hidden untuk menyimpan kode_tarif yang diedit
            $("#form_tarif").append("<input type='hidden' name='kode_tarif' value='" + e[2] + "'>");
        }
        const datatablesSimple = document.getElementById('tarif_table');
            if (datatablesSimple) {
                new simpleDatatables.DataTable(datatablesSimple);
            }       
        // menyisipkan tombol tarif pada dropdown
        $(".datatable-dropdown").append("<button type=button class='btn btn-outline-success float-start me-2'><i class='fas fa-money-bill'></i> Tarif</button>");
        // membuat tombol tarif dapat diklik
        $(".datatable-dropdown button").click(function() {
           // console.log("tombol tarif diklik");
            $("#tarif_add").show();
            $("#tarif_list").hide();
            $("#form_tarif input[type='text'], #form_tarif input[type='number'], #form_tarif textarea").val("");
            $("#form_tarif input[type='radio']").prop("checked", false);
        });
        //membuat konfirmasi hapus data tarif
        $("button[data-bs-toggle='modal']").click(function() {
            kode_tarif=$(this).attr('data-tarif');
            $("#myModal .modal-body").text("Apakah Anda yakin ingin menghapus data tarif " + kode_tarif + "?");  
            $(".modal-footer form input[name='user'], .modal-footer form input[name='tarif'], .modal-footer form input[name='kode_tarif']").remove();
            $(".modal-footer form").append("<input type='hidden' name='kode_tarif' value='" + kode_tarif + "'>");
            $(".modal-footer form button[name='tombol']").val("tarif_hapus");
        });
    } else {
        // diklik dashboard
        // id summary, chart disembunyikan
        $("#summary,#chart").show();
        $("#tarif_add,#tarif_list,#user_add,#user_list").hide();
  }
  
});
