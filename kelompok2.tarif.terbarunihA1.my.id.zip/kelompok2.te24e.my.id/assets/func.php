<?php
    class klas_air
    {
        function koneksi(){
            $koneksi = mysqli_connect("localhost", "teemyid_kelompok2", "(h5.K68.pT#$!km_", "teemyid_kelompok2");
            return $koneksi;
        }
        function dt_user($sesi_user){
            $q=mysqli_query($this->koneksi(), "SELECT nama,kota,level FROM login WHERE username='$sesi_user'");
            $d=mysqli_fetch_row($q);
            return $d;
        }
    }
?>