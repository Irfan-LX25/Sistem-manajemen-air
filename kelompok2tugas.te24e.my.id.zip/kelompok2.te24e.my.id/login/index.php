<?php
session_start();
if(empty($_SESSION['user']) && empty($_SESSION['pass'])){
    echo"<script>window.location.replace('../index.php');</script>";
}

// koneksi ke database MySQL
include '../assets/func.php';
$air=new klas_air();
$koneksi=$air->koneksi();
$dt_user=$air->dt_user($_SESSION['user']);
$user_level=$dt_user[2];
$pass2 = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['level'])) $level = $_POST['level'];
    if (isset($_POST['tipe'])) $tipe = $_POST['tipe'];
    if (isset($_POST['status'])) $status = $_POST['status'];
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - kelompok 2</title>
        <link rel="icon" href="../assets/img/polines.png"> 
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>var user_level = "<?php echo $user_level; ?>";</script>
        <script src="../js/air.js"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.html">Start Bootstrap</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link <?php if(!isset($_GET['page']) || $_GET['page'] == '') echo 'active'; ?>" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-gauge-high fa-beat text-primary"></i></div>
                                Dashboard
                            </a>
                            <?php
                            if ($user_level == 'Admin'){
                            ?>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-user') echo 'active'; ?>" href="index.php?page=manajemen-data-user">
                                <div class="sb-nav-link-icon"><i class="fas fa-users fa-beat-fade text-info"></i></div>
                                    Manajemen Data User
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-tarif-air') echo 'active'; ?>" href="index.php?page=manajemen-data-tarif-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-hand-holding-droplet fa-shake text-primary"></i></div>
                                    Manajemen Data Tarif Air
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-faucet-drip fa-flip text-success"></i></div>
                                    Manajemen Pemakaian Air
                            </a>
                            <?php
                            } elseif ($user_level == 'Bendahara') {
                            ?>
                            <!-- <a class="nav-link" href="index.php?page=ubah-data-meter-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-pen-to-square fa-beat text-warning"></i></div>
                                    Ubah Data Meter Warga
                            </a> -->
                            <!-- <a class="nav-link" href="index.php?page=hapus-data-meter-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-trash fa-shake text-danger"></i></div>
                                    Hapus Data Meter Warga
                            </a> -->
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-invoice-dollar fa-beat text-success"></i></div>
                                    Lihat Pemakaian Warga
                            </a>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'manajemen-data-tarif-air') echo 'active'; ?>" href="index.php?page=manajemen-data-tarif-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-hand-holding-droplet fa-shake text-primary"></i></div>
                                    Manajemen Data Tarif Air
                            </a>
                            <!-- <a class="nav-link" href="index.php?page=lihat-infografis-tagihan-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-line fa-fade text-info"></i></div>
                                    Lihat Infografis Tagihan Air
                            </a> -->
                            <?php
                            } elseif ($user_level == 'Warga') {
                            ?>
                            <a class="nav-link <?php if(isset($_GET['p']) && $_GET['p'] == 'pemakaian_sendiri_list') echo 'active'; ?>" href="index.php?p=pemakaian_sendiri_list">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-invoice-dollar fa-bounce text-warning"></i></div>
                                    Lihat Pemakaian
                            </a>
                            <!-- <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'pantau-pemakaian-air-tiap-bulan') echo 'active'; ?>" href="index.php?page=pantau-pemakaian-air-tiap-bulan">
                                <div class="sb-nav-link-icon"><i class="fas fa-eye fa-bounce text-primary"></i></div>
                                    Pantau Pemakaian Air Tiap Bulan
                            </a> -->
                            <!-- <a class="nav-link" href="index.php?page=lihat-tagihan-tiap-bulan">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-invoice fa-beat-fade text-success"></i></div>
                                    Lihat Tagihan Tiap Bulan
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-infografis-tagihan-dan-pemakaian-air-bulanan">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area fa-fade text-info"></i></div>
                                    Lihat Infografis Tagihan dan Pemakaian Air Bulanan
                            </a> -->
                            <?php
                            }elseif ($user_level == 'Petugas') {
                            ?>
                            <a class="nav-link <?php if(isset($_GET['page']) && $_GET['page'] == 'masukkan-data-meter-pemakaian-air') echo 'active'; ?>" href="index.php?page=masukkan-data-meter-pemakaian-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-pen fa-beat text-warning"></i></div>
                                    Masukkan Data Meter Pemakaian Air
                            </a>
                            <!-- <a class="nav-link" href="index.php?page=ubah-data-meter-air-1-bulan-terakhir">
                                <div class="sb-nav-link-icon"><i class="fas fa-rotate fa-spin text-secondary"></i></div>
                                    Ubah Data Meter air 1 bulan terakhir
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-jumlah-total-pelanggan">
                                <div class="sb-nav-link-icon"><i class="fas fa-user-group fa-bounce text-primary"></i></div>
                                    Lihat Jumlah Total Pelanggan
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-jumlah-pemakaian-air-seluruh-warga">
                                <div class="sb-nav-link-icon"><i class="fas fa-faucet-drip fa-flip text-success"></i></div>
                                    Lihat Jumlah Pemakaian Air Seluruh Warga
                            </a>
                            <a class="nav-link" href="index.php?page=lihat-infografis-pemakaian-air">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-column fa-fade text-info"></i></div>
                                    Lihat Infografis Pemakaian Air
                            </a> -->
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small"><i class="fa-solid fa-user-secret fa-beat-fade text-warning"></i> Logged in as: <?php echo $dt_user[2]; ?></div>
                        <i class="fa-solid fa-map-pin fa-flip text-danger"></i> <?php echo $dt_user[0].' ('.$dt_user[1].')'; ?> 
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php
                        $e = explode('=', $_SERVER['REQUEST_URI']);
                        if (!empty($e[1])) {
                            if ($e[1] == 'manajemen-data-user' || $e[1] == 'user_edit&user'){
                                $h1 = 'Manajemen Data User';
                                $li = 'Menu untuk CRUD User';
                            }elseif ($e[1] == 'manajemen-data-tarif-air'|| $e[1] == 'tarif_edit&kode_tarif'){
                                $h1 = 'Manajemen Data tarif air';
                                $li = 'Menu untuk memanajemen data tarif air';
                            }elseif ($e[1] == 'manajemen-pemakaian-air'){
                                $h1 = 'Manajemen Pemakaian Air';
                                $li = 'Menu untuk memanajemen data pemakaian air';
                            }elseif ($e[1] == 'ubah-data-meter-warga'){
                                $h1 = 'Ubah Data Meter Warga';
                                $li = 'Menu untuk mengubah data meter warga';
                            }elseif ($e[1] == 'hapus-data-meter-warga'){
                                $h1 = 'Hapus Data Meter Warga';
                                $li = 'Menu untuk menghapus data meter warga'; 
                            }elseif ($e[1] == 'lihat-tagihan-seluruh-warga'){
                                $h1 = 'Lihat Tagihan Seluruh Warga';
                                $li = 'Menu untuk melihat tagihan seluruh warga';
                            }elseif ($e[1] == 'lihat-infografis-tagihan-air'){
                                $h1 = 'Lihat Infografis Tagihan Air';
                                $li = 'Menu untuk melihat infografis tagihan air';
                            }elseif ($e[1] == 'pantau-pemakaian-air-tiap-bulan'){
                                $h1 = 'Pantau Pemakaian Air Tiap Bulan';
                                $li = 'Menu untuk memantau pemakaian air tiap bulan';
                            }elseif ($e[1] == 'lihat-tagihan-tiap-bulan'){
                                $h1 = 'Lihat Tagihan Tiap Bulan';
                                $li = 'Menu untuk melihat tagihan tiap bulan';
                            }elseif ($e[1] == 'lihat-infografis-tagihan-dan-pemakaian-air-bulanan'){
                                $h1 = 'Lihat Infografis Tagihan dan Pemakaian Air Bulanan';
                                $li = 'Menu untuk melihat infografis tagihan dan pemakaian air bulanan';
                            }elseif ($e[1] == 'pemakaian_sendiri_list'){
                                $h1 = 'Pemakaian & Tagihan Air';
                                $li = 'Data Pemakaian & Tagihan Air';
                            }elseif ($e[1] == 'masukkan-data-meter-pemakaian-air'|| $e[1] == 'meter_edit&no'){
                                $h1 = 'Masukkan Data Meter Pemakaian Air';
                                $li = 'Menu untuk memasukkan data meter pemakaian air';
                            }elseif ($e[1] == 'ubah-data-meter-air-1-bulan-terakhir'){
                                $h1 = 'Ubah Data Meter Air 1 Bulan Terakhir';
                                $li = 'Menu untuk mengubah data meter air 1 bulan terakhir';
                            }elseif ($e[1] == 'lihat-jumlah-total-pelanggan'){
                                $h1 = 'Lihat Jumlah Total Pelanggan';
                                $li = 'Menu untuk melihat jumlah total pelanggan';
                            }elseif ($e[1] == 'lihat-jumlah-pemakaian-air-seluruh-warga'){
                                $h1 = 'Lihat Jumlah Pemakaian Air Seluruh Warga';
                                $li = 'Menu untuk melihat jumlah pemakaian air seluruh warga';
                            }elseif ($e[1] == 'lihat-infografis-pemakaian-air'){
                                $h1 = 'Lihat Infografis Pemakaian Air';
                                $li = 'Menu untuk melihat infografis pemakaian air';
                        }
                        }else {
                            $h1 = 'Dashboard';
                            $li = 'Selamat datang di dashboard';
                        }                       
                        ?>
                        <h1 class="mt-4"><?php echo $h1; ?></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><?php echo $li; ?></li>
                        </ol>
                        <div class="row" id="summary">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Primary Card</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Warning Card</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Success Card</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">Danger Card</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="chart">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area me-1"></i>
                                        Area Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Bar Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                        </div>
                        <?php
                        if(isset($_POST['tombol'])){
                            $t=$_POST['tombol'];
                            if ($t == 'user_add'){
                                $user = $_POST['user'];
                                $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
                                $nama = $_POST['nama'];
                                $alamat = $_POST['alamat'];
                                $kota = $_POST['kota'];
                                $tlp = $_POST['tlp'];
                                $level = $_POST['level'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];

                               //Cek username sudah ada atau belum
                                $qc = mysqli_query($koneksi, "SELECT username FROM login WHERE username='$user'");
                                $dc = mysqli_fetch_row($qc);

                                if (empty($dc)){
                                    mysqli_query($koneksi, "INSERT INTO login(username,password,nama,alamat,kota,tlp,level,tipe,status) VALUES ('$user','$pass','$nama','$alamat','$kota','$tlp','$level','$tipe','$status')");
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user berhasil ditambahkan...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user gagal ditambahkan...
                                        </div>";
                                    }
                                }
                                else {
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Username $user</strong> sudah ada, gunakan username lain...
                                    </div>";
                                }
                            }elseif($t == "user_edit"){
                                $user = $_POST['user'];
                                $pass = trim($_POST['password']);
                                $nama = $_POST['nama'];
                                $alamat = $_POST['alamat'];
                                $kota = $_POST['kota'];
                                $tlp = $_POST['tlp'];
                                $level = $_POST['level'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];

                                //Jika password kosong, password lama tetap dipakai.
                                if ($pass === ''){
                                $qu = mysqli_query($koneksi, "UPDATE login SET nama=\"$nama\", alamat='$alamat', kota='$kota', tlp='$tlp', level='$level', tipe='$tipe', status='$status' WHERE username='$user'");
                                } else {
                                    $pass2 = password_hash($pass, PASSWORD_DEFAULT);
                                    $qu = mysqli_query($koneksi, "UPDATE login SET password='$pass2', nama=\"$nama\", alamat='$alamat', kota='$kota', tlp='$tlp', level='$level', tipe='$tipe', status='$status' WHERE username='$user'");
                                }

                                if ($qu === false) {
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user gagal diubah...
                                    </div>";
                                } elseif(mysqli_affected_rows($koneksi) > 0){
                                    echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user berhasil diubah...
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-user'; }, 1500);</script>";
                                } else {
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> user tidak ada perubahan..
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-user'; }, 1500);</script>";
                                }

                               
                            } elseif ($t =="user_hapus"){
                                $user = $_POST['user'];
                                mysqli_query($koneksi, "DELETE FROM login WHERE username='$user'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> user gagal dihapus...
                                        </div>";
                                }
                                
                            } elseif ($t == 'tarif_add'){
                                $kode_tarif = $_POST['kode_tarif'];
                                $tarif = $_POST['tarif'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];
                                    mysqli_query($koneksi, "INSERT INTO tarif(kd_tarif,tarif,tipe,status) VALUES ('$kode_tarif','$tarif','$tipe','$status')");
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif berhasil ditambahkan...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif gagal ditambahkan...
                                        </div>";
                                    }
                            } elseif($t == "tarif_edit"){
                                $kode_tarif = $_POST['kode_tarif'];
                                $tarif = $_POST['tarif'];
                                $tipe = $_POST['tipe'];
                                $status = $_POST['status'];
                                mysqli_query($koneksi, "UPDATE tarif SET tarif='$tarif', tipe='$tipe', status='$status' WHERE kd_tarif='$kode_tarif'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                    echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> tarif berhasil diubah...
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-tarif-air'; }, 1500);</script>";
                                } else {
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> tarif tidak ada perubahan..
                                    </div>";
                                    echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=manajemen-data-tarif-air'; }, 1500);</script>";
                                }

                               
                            } elseif ($t =="tarif_hapus"){
                                $kode_tarif = $_POST['kode_tarif'] ?? ($_POST['tarif'] ?? '');
                                mysqli_query($koneksi, "DELETE FROM tarif WHERE kd_tarif='$kode_tarif'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> tarif gagal dihapus...
                                        </div>";
                                }
                                
                            } elseif ($t == 'meter_add'){
                                $username = $_POST['username'];
                                
                                // Cek apakah data warga sudah ada di bulan yang sama
                                $bulan_sekarang = date('m');
                                $tahun_sekarang = date('Y');
                                $cek_query = mysqli_query($koneksi, "SELECT * FROM pemakaian WHERE username='$username' AND MONTH(tgl)='$bulan_sekarang' AND YEAR(tgl)='$tahun_sekarang'");
                                
                                if(mysqli_num_rows($cek_query) > 0){
                                    echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Peringatan!</strong> Data meter untuk warga ini sudah diinput pada bulan ini...
                                    </div>";
                                    echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                } else {
                                    $meter_awal = $_POST['meter_awal'];
                                    $meter_akhir = $_POST['meter_akhir'];
                                    $kd_tarif = $air->user_to_idtarif($username);
                                    $tarif = $air->kdtarif_to_tarif($kd_tarif);
                                    $pemakaian = $meter_akhir - $meter_awal;
                                    $tagihan = $tarif * $pemakaian;
                                    if($pemakaian < 0){
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter akhir harus lebih besar dari meter awal...
                                        </div>";
                                        echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                    } else {
                                        $status_meter_insert = isset($_POST['status_meter']) ? $_POST['status_meter'] : 'Belum Lunas';
                                        mysqli_query($koneksi, "INSERT INTO pemakaian(username,meter_awal,meter_akhir,pemakaian,tgl,waktu,kd_tarif,tagihan,status) VALUES ('$username','$meter_awal','$meter_akhir','$pemakaian',current_date(),current_time(),'$kd_tarif','$tagihan','$status_meter_insert')");
                                        if(mysqli_affected_rows($koneksi) > 0){
                                            echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                            <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                            <strong>Data</strong> meter berhasil ditambahkan...
                                            </div>";
                                        } else {
                                            echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                            <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                            <strong>Data</strong> meter gagal ditambahkan...
                                            </div>";
                                        }
                                    }
                                }
                            } elseif($t == "meter_edit"){
                                $no = $_POST['no'];
                                $meter_awal = $_POST['meter_awal'];
                                $meter_akhir = $_POST['meter_akhir'];
                                $username = $air->no_to_username($no);
                                $kd_tarif = $air->user_to_idtarif($username);
                                $tarif = $air->kdtarif_to_tarif($kd_tarif);
                                $pemakaian = $meter_akhir - $meter_awal;
                                $tagihan = $tarif * $pemakaian;
                                if($pemakaian < 0){
                                    echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                    <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                    <strong>Data</strong> meter akhir harus lebih besar dari meter awal...
                                    </div>";
                                    echo "<script>$(document).ready(function(){ $('#meter_add').show(); $('#meter_list').hide(); });</script>";
                                } else {
                                    if(isset($_POST['status_meter'])){
                                        $status_meter_update = $_POST['status_meter'];
                                        mysqli_query($koneksi, "UPDATE pemakaian SET meter_awal='$meter_awal', meter_akhir='$meter_akhir', pemakaian='$pemakaian', tagihan='$tagihan', status='$status_meter_update' WHERE no='$no'");
                                    } else {
                                        mysqli_query($koneksi, "UPDATE pemakaian SET meter_awal='$meter_awal', meter_akhir='$meter_akhir', pemakaian='$pemakaian', tagihan='$tagihan' WHERE no='$no'");
                                    }
                                    if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter berhasil diubah...
                                        </div>";
                                        echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=masukkan-data-meter-pemakaian-air'; }, 1500);</script>";
                                    } else {
                                        echo "<div class=\"alert alert-warning alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter tidak ada perubahan..
                                        </div>";
                                        echo "<script>setTimeout(function(){ window.location.href = 'index.php?page=masukkan-data-meter-pemakaian-air'; }, 1500);</script>";
                                    }
                                }

                               
                            } elseif ($t =="meter_hapus"){
                                $no = $_POST['no'];
                                mysqli_query($koneksi, "DELETE FROM pemakaian WHERE no='$no'");
                                if(mysqli_affected_rows($koneksi) > 0){
                                        echo "<div class=\"alert alert-success alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter berhasil dihapus...
                                        </div>";
                                    } else {
                                        echo "<div class=\"alert alert-danger alert-dismissible fade show\">
                                        <button type='button' class=btn-close data-bs-dismiss=alert></button>
                                        <strong>Data</strong> meter gagal dihapus...
                                        </div>";
                                }
                                
                            }
                        } elseif (isset($_GET['p'])) {
                            $p = $_GET['p'];
                            if ($p == 'user_edit') {
                                $user = $_GET['user'];
                                $qc = mysqli_query($koneksi, "SELECT password,nama,alamat,kota,tlp,level,tipe,status FROM login WHERE username='$user'");
                                $dc = mysqli_fetch_row($qc);
                                $pass2 = '';
                                $nama = $dc[1];
                                $alamat = $dc[2];
                                $kota = $dc[3];
                                $tlp = $dc[4];
                                $level = $dc[5];
                                $tipe = $dc[6];
                                $status = $dc[7];
                            } elseif ($p == 'tarif_edit') {
                                $kode_tarif = $_GET['kode_tarif'];
                                $qc = mysqli_query($koneksi, "SELECT tarif,tipe,status FROM tarif WHERE kd_tarif='$kode_tarif'");
                                $dc = mysqli_fetch_row($qc);
                                $tarif = $dc[0];
                                $tipe = $dc[1];
                                $status = $dc[2];
                            } elseif ($p == 'meter_edit') {
                                $no = $_GET['no'];
                                $qc = mysqli_query($koneksi, "SELECT username,meter_awal,meter_akhir,pemakaian,status FROM pemakaian WHERE no='$no'");
                                $dc = mysqli_fetch_row($qc);
                                $username = $dc[0];
                                $meter_awal = $dc[1];
                                $meter_akhir = $dc[2];
                                $pemakaian = $dc[3];
                                $status_meter = $dc[4];
                            }
                            
                        }
                        ?>
                        <div class="modal" id="myModal">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Konfirmasi hapus data</h4>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <!-- Modal body -->
                                <div class="modal-body">
                                </div>

                                <!-- Modal footer -->
                                <div class="modal-footer">
                                    <form method="post">
                                        <button type="submit" name="tombol" value="/" class="btn btn-danger"  data-bs-dismiss="modal">Ya</button>
                                    </form>
                                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Tidak</button>
                                </div>

                                </div>
                            </div>
                        </div>
                        <div class="card mb-4" id ="user_add">
                            <div class="card-header">
                                <i class="fa-solid fa-user-plus me-2 text-success fa-fade"></i>
                                User
                            </div>
                            <div class="card-body">
                                <form method="post" class="needs-validation" id="form_user">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username:</label>
                                        <input type="text" class="form-control" id="username" placeholder="Masukkan username" name="user" value="<?php echo $user ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password:</label>
                                        <input type="password" class="form-control" id="password" placeholder="Masukkan password" name="password" value="<?php echo $pass2 ?>" <?php if (!isset($_GET['p']) || $_GET['p'] != 'user_edit') echo 'required'; ?>>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama" class="form-label">Nama:</label>
                                        <input type="text" class="form-control" id="nama" placeholder="Masukkan nama" name="nama" value="<?php echo $nama ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat">Alamat:</label>
                                        <textarea class="form-control" rows="5" id="alamat" name="alamat"><?php echo $alamat ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="kota" class="form-label">Kota:</label>
                                        <input type="text" class="form-control" id="kota" placeholder="Masukkan kota" name="kota" value="<?php echo $kota ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="tlp" class="form-label">Telepon:</label>
                                        <input type="text" class="form-control" id="tlp" placeholder="Masukkan telepon" name="tlp" value="<?php echo $tlp ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="level" class="form-label">Level:</label>
                                        <div class="d-flex gap-3 flex-wrap">
                                            <?php
                                            $lv = array(
                                                'Admin' => 'fa-user-shield text-danger',
                                                'Bendahara' => 'fa-wallet text-warning',
                                                'Warga' => 'fa-house-user text-success',
                                                'Petugas' => 'fa-user-tie text-primary'
                                            );
                                            foreach ($lv as $lv2 => $icon) {
                                                $checked = ($level == $lv2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='level' id='level_$lv2' value='$lv2' $checked>";
                                                echo "<label class='form-check-label' for='level_$lv2'><i class='fas $icon me-1'></i>" . ucwords($lv2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipe" class="form-label">Tipe:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $t = array(
                                                'RT' => 'fa-building text-info',
                                                'Kos' => 'fa-bed text-secondary'
                                            );
                                            foreach ($t as $t2 => $icon) {
                                                $checked = ($tipe == $t2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='tipe' id='tipe_$t2' value='$t2' $checked>";
                                                echo "<label class='form-check-label' for='tipe_$t2'><i class='fas $icon me-1'></i>" . ucwords($t2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $st = array('Aktif', 'Non-Aktif');
                                            foreach ($st as $st2) {
                                                $checked = ($status == $st2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='status' id='status_$st2' value='$st2' $checked>";
                                                echo "<label class='form-check-label' for='status_$st2'>" . ucwords($st2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary" name="tombol" value="user_add">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <div class="card mb-4" id ="tarif_add">
                            <div class="card-header">
                                <i class="fa-solid fa-hand-holding-droplet me-2 text-primary fa-shake"></i>
                                Data Tarif
                            </div>
                            <div class="card-body">
                                <form method="post" class="needs-validation" id="form_tarif">
                                    <div class="mb-3">
                                        <label for="kode_tarif" class="form-label">Kode Tarif:</label>
                                        <input type="text" class="form-control" id="kode_tarif" placeholder="Masukkan kode tarif" name="kode_tarif" value="<?php echo $kode_tarif ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tarif" class="form-label">Tarif:</label>
                                        <input type="number" class="form-control" id="tarif" placeholder="Masukkan tarif" name="tarif" value="<?php echo $tarif ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipe" class="form-label">Tipe:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $t = array(
                                                'RT' => 'fa-building text-info',
                                                'Kos' => 'fa-bed text-secondary'
                                            );
                                            foreach ($t as $t2 => $icon) {
                                                $checked = ($tipe == $t2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='tipe' id='tipe_$t2' value='$t2' $checked>";
                                                echo "<label class='form-check-label' for='tipe_$t2'><i class='fas $icon me-1'></i>" . ucwords($t2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status:</label>
                                        <div class="d-flex gap-3">
                                            <?php
                                            $st = array('Aktif', 'Non-Aktif');
                                            foreach ($st as $st2) {
                                                $checked = ($status == $st2) ? 'checked' : '';
                                                echo "<div class='form-check form-check-inline'>";
                                                echo "<input class='form-check-input' type='radio' name='status' id='status_$st2' value='$st2' $checked>";
                                                echo "<label class='form-check-label' for='status_$st2'>" . ucwords($st2) . "</label>";
                                                echo "</div>";
                                            }
                                            ?>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary" name="tombol" value="tarif_add">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <?php if ($user_level != 'Bendahara' || ($user_level == 'Bendahara' && $e[1] == "meter_edit&no")) { ?>
                        <div class="card mb-4" id ="meter_add">
                            <div class="card-header">
                                <i class="fa-solid fa-faucet-drip me-2 text-success fa-flip"></i>
                                Data Meter
                            </div>
                            <div class="card-body">
                                <?php
                                if ($e[1] == "meter_edit&no") {
                                    $disable = 'disabled';
                                    $readonly_bendahara = ($user_level == 'Bendahara') ? 'readonly' : '';
                                } else {
                                    $disable = '';
                                    $readonly_bendahara = '';
                                    $status_meter = '';
                                }
                                ?>
                                <form method="post" class="needs-validation" id="form_meter">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Nama Warga:</label>
                                        <select class="form-select" name="username" required <?php echo $disable ?>>
                                            <option value="">Nama Warga </option>
                                            <?php
                                            $q = mysqli_query($koneksi, "SELECT username, nama FROM login WHERE level='Warga' ORDER BY nama ASC");
                                            while ($d = mysqli_fetch_row($q)) {
                                                if ($username == $d[0]) $selected = 'selected';
                                                else $selected = '';
                                                echo "<option value='$d[0]' $selected>$d[1]</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="meter_awal" class="form-label">Meter Awal (m<sup>3</sup>):</label>
                                        <input type="text" class="form-control" id="meter_awal" placeholder="Masukkan meter awal " name="meter_awal" value="<?php echo $meter_awal ?>" required <?php echo $readonly_bendahara; ?>>
                                    </div>
                                    <div class="mb-3">
                                        <label for="meter_akhir" class="form-label">Meter Akhir (m<sup>3</sup>):</label>
                                        <input type="number" class="form-control" id="meter_akhir" placeholder="Masukkan meter akhir " name="meter_akhir" value="<?php echo $meter_akhir ?>" required <?php echo $readonly_bendahara; ?>>
                                    </div>
                                    <?php if ($user_level == 'Admin' || ($user_level == 'Bendahara' && $e[1] == "meter_edit&no")) { ?>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status:</label>
                                        <div class="d-flex gap-3 mt-1">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="status_meter" id="status_lunas" value="Lunas" <?php if($status_meter=='Lunas') echo 'checked'; ?> required>
                                                <label class="form-check-label" for="status_lunas">LUNAS</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="status_meter" id="status_blm_lunas" value="Belum Lunas" <?php if($status_meter=='Belum Lunas' || $status_meter=='') echo 'checked'; ?> required>
                                                <label class="form-check-label" for="status_blm_lunas">BLM LUNAS</label>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <!-- Hidden input for "no" when editing is needed because disable select doesn't send "username" but we use $_POST['no'] for edit -->
                                    <?php if($e[1] == "meter_edit&no") { echo "<input type='hidden' name='no' value='$no'>"; } ?>
                                    <button type="submit" class="btn btn-primary" name="tombol" value="<?php echo ($e[1] == "meter_edit&no") ? 'meter_edit' : 'meter_add'; ?>">Simpan</button>
                                </form> 
                            </div>
                        </div>
                        <?php } ?>
                        <div class="card mb-4" id ="user_list">
                            <div class="card-header">
                                <i class="fa-solid fa-users me-2 text-success fa-fade"></i>
                                Data User
                            </div>
                            <div class="card-body table-responsive">
                                <table id="datatablesSimple" class="table table-sm table-striped table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>Nama</th>
                                            <th>Alamat</th>
                                            <th>Kota</th>
                                            <th>Telepon</th>
                                            <th>Level</th>
                                            <th>Tipe</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT username,nama,alamat,kota,tlp,level,tipe,status FROM login ORDER BY level ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $user = $d[0];
                                            $nama = $d[1];
                                            $alamat = $d[2];
                                            $kota = $d[3];
                                            $tlp = $d[4];
                                            $level = $d[5];
                                            $tipe = $d[6];
                                            $status = $d[7];
                                            echo "<tr>
                                                    <td>$user</td>
                                                    <td>$nama</td>
                                                    <td>$alamat</td>
                                                    <td>$kota</td>
                                                    <td>$tlp</td>
                                                    <td>$level</td>
                                                    <td>$tipe</td>
                                                    <td>$status</td>
                                                    <td>
                                                        <div class='d-flex flex-nowrap gap-1'>
                                                            <a href=index.php?p=user_edit&user=$user><button type=button class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></button></a>
                                                            <button type=button class='btn btn-outline-danger' data-bs-toggle=modal data-bs-target=#myModal data-user=$user><i class='fas fa-trash'></i></button>
                                                        </div>
                                                    </td>
                                                </tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id ="tarif_list">
                            <div class="card-header">
                                <i class="fa-solid fa-hand-holding-droplet me-2 text-primary fa-shake"></i>
                                Data Tarif
                            </div>
                            <div class="card-body table-responsive">
                                <table id="tarif_table" class="table table-sm table-striped table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>Kode Tarif</th>
                                            <th>Tarif</th>
                                            <th>Tipe</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT kd_tarif,tarif,tipe,status FROM tarif ORDER BY kd_tarif ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $kode_tarif = $d[0];
                                            $tarif = $d[1];
                                            $tipe = $d[2];
                                            $status = $d[3];
                                            echo "<tr>
                                                    <td>$kode_tarif</td>
                                                    <td>$tarif</td>
                                                    <td>$tipe</td>
                                                    <td>$status</td>
                                                    <td>
                                                        <div class='d-flex flex-nowrap gap-1'>
                                                            <a href=index.php?p=tarif_edit&kode_tarif=$kode_tarif><button type=button class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></button></a>
                                                            <button type=button class='btn btn-outline-danger' data-bs-toggle=modal data-bs-target=#myModal data-tarif=$kode_tarif><i class='fas fa-trash'></i></button>
                                                        </div>
                                                    </td>
                                                </tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id ="meter_list">
                            <div class="card-header">
                                <i class="fa-solid fa-faucet-drip me-2 text-success fa-flip"></i>
                                Data Meter Warga
                            </div>
                            <div class="card-body table-responsive">
                                <table id="meter_table" class="table table-sm table-striped table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>Nama Warga</th>
                                            <th>Tipe</th>
                                            <th>Tanggal & Waktu</th>
                                            <th>Meter Awal (m<sup>3</sup>)</th>
                                            <th>Meter Akhir (m<sup>3</sup>)</th>
                                            <th>Pemakaian (m<sup>3</sup>)</th>
                                            <?php if ($user_level == 'Bendahara' || $user_level == 'Admin') { ?>
                                            <th>Tagihan (Rp)</th>
                                            <th class="text-center">Status</th>
                                            <?php } ?>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $q = mysqli_query($koneksi,"SELECT no,username,meter_awal,meter_akhir,pemakaian,tgl,waktu,tagihan,status FROM pemakaian ORDER BY tgl DESC, username ASC");
                                        while($d=mysqli_fetch_row($q)){
                                            $no = $d[0];
                                            $dt_user2 = $air->dt_user($d[1]);
                                            $nama = $dt_user2[0];
                                            $tipe_warga = $dt_user2[3];
                                            $meter_awal = $d[2];
                                            $meter_akhir = $d[3];
                                            $pemakaian = $d[4];
                                            $tgl = $air->tgl_walik($d[5]);
                                            $waktu = $d[6];
                                            $tagihan = $d[7];
                                            $status_tagihan = $d[8];
                                            $level_login = $dt_user[2];
                                            $tgl_meter = date_create($d[5]);
                                            $tgl_sekarang = date_create();
                                            $diff = date_diff($tgl_meter, $tgl_sekarang);
                                            $selisih =$diff->days;
                                            $indo = [
                                                'Monday'=>'Senin', 'Tuesday'=>'Selasa', 'Wednesday'=>'Rabu', 'Thursday'=>'Kamis', 
                                                'Friday'=>'Jumat', 'Saturday'=>'Sabtu', 'Sunday'=>'Minggu',
                                                'January'=>'Januari', 'February'=>'Februari', 'March'=>'Maret', 'April'=>'April', 
                                                'May'=>'Mei', 'June'=>'Juni', 'July'=>'Juli', 'August'=>'Agustus', 
                                                'September'=>'September', 'October'=>'Oktober', 'November'=>'November', 'December'=>'Desember'
                                            ];
                                            $tgl_tampil = strtr(date("l, d F Y", strtotime($tgl)), $indo);
                                            $hari_ini   = strtr(date("d-m-Y", strtotime(date("Y-m-d"))), $indo);

                                            echo "<tr>
                                                    <td>$nama </td>
                                                    <td>$tipe_warga</td>
                                                    <td>$tgl_tampil  $waktu 
                                                    <hr class='my-1'>
                                                    $hari_ini ($selisih hari)</td> 
                                                    <td>$meter_awal</td>
                                                    <td>$meter_akhir</td>
                                                    <td>$pemakaian</td>";
                                                    
                                            if ($user_level == 'Bendahara' || $user_level == 'Admin') {
                                                $badge_color = ($status_tagihan == 'Lunas') ? 'bg-success' : 'bg-danger';
                                                $status_display = strtoupper($status_tagihan);
                                                echo "<td>$tagihan</td>
                                                      <td class='text-center align-middle'><span class='badge $badge_color p-2' style='width: 100px;'>$status_display</span></td>";
                                            }
                                            if ($level_login == 'Admin' || $level_login == 'Bendahara'){
                                                echo "<td class='text-center align-middle'>
                                                        <div class='d-flex flex-nowrap gap-1 justify-content-center'>
                                                            <a href='index.php?p=meter_edit&no=$no' class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></a>
                                                            <button type='button' class='btn btn-outline-danger' data-bs-toggle='modal' data-bs-target='#myModal' data-no='$no'><i class='fas fa-trash'></i></button>
                                                        </div>
                                                    </td>";

                                            } else{
                                                if($selisih <=30){
                                                    echo "<td class='text-center align-middle'>
                                                            <div class='d-flex flex-nowrap gap-1 justify-content-center'>
                                                                <a href='index.php?p=meter_edit&no=$no' class='btn btn-outline-primary'><i class='fas fa-pen-to-square'></i></a>
                                                                <button type='button' class='btn btn-outline-danger' data-bs-toggle='modal' data-bs-target='#myModal' data-no='$no'><i class='fas fa-trash'></i></button>
                                                            </div>
                                                        </td>";
                                                } else {
                                                    echo "<td></td>";
                                                }
                                            }
                                             echo "</tr>";
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4" id="pemakaian_sendiri_list" style="display: none;">
                            <div class="card-header">
                                <i class="fas fa-file-invoice-dollar me-2 text-success fa-bounce"></i>
                                Data Pemakaian dan Pembayaran
                            </div>
                            <div class="card-body table-responsive">
                                <table id="pemakaian_sendiri_table" class="table table-sm table-striped table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Waktu Pencatatan Meter</th>
                                            <th class="text-center">Kode Tarif</th>
                                            <th class="text-center">Meter Awal (m<sup>3</sup>)</th>
                                            <th class="text-center">Meter Akhir (m<sup>3</sup>)</th>
                                            <th class="text-center">Pemakaian (m<sup>3</sup>)</th>
                                            <th class="text-center">Tagihan (Rp)</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (isset($_SESSION['user'])) {
                                            $user_login = $_SESSION['user'];
                                            $q_pemakaian = mysqli_query($koneksi,"SELECT tgl, waktu, kd_tarif, meter_awal, meter_akhir, pemakaian, tagihan, status FROM pemakaian WHERE username='$user_login' ORDER BY tgl DESC");
                                            while($dp = mysqli_fetch_row($q_pemakaian)){
                                                $tgl = $air->tgl_walik($dp[0]);
                                                $waktu = $dp[1];
                                                $kd_tarif = $dp[2];
                                                $meter_awal = $dp[3];
                                                $meter_akhir = $dp[4];
                                                $pemakaian = $dp[5];
                                                $tagihan = $dp[6];
                                                $status_tagihan = $dp[7];
                                                
                                                $badge_color = (strtolower($status_tagihan) == 'lunas') ? 'bg-success' : 'bg-danger';
                                                $status_display = strtoupper($status_tagihan);
                                                $indo = [
                                                'Monday'=>'Senin', 'Tuesday'=>'Selasa', 'Wednesday'=>'Rabu', 'Thursday'=>'Kamis', 
                                                'Friday'=>'Jumat', 'Saturday'=>'Sabtu', 'Sunday'=>'Minggu',
                                                'January'=>'Januari', 'February'=>'Februari', 'March'=>'Maret', 'April'=>'April', 
                                                'May'=>'Mei', 'June'=>'Juni', 'July'=>'Juli', 'August'=>'Agustus', 
                                                'September'=>'September', 'October'=>'Oktober', 'November'=>'November', 'December'=>'Desember'
                                                ];
                                                $tgl_tampil = strtr(date("l, d F Y", strtotime($tgl)), $indo);
                                                
                                                echo "<tr>
                                                        <td class='text-center'>$tgl_tampil $waktu</td>
                                                        <td class='text-center'>$kd_tarif</td>
                                                        <td class='text-center'>$meter_awal</td>
                                                        <td class='text-center'>$meter_akhir</td>
                                                        <td class='text-center'>$pemakaian</td>
                                                        <td class='text-center'>$tagihan</td>
                                                        <td class='text-center align-middle'><span class='badge $badge_color p-2' style='width: 100px;'>$status_display</span></td>
                                                    </tr>";
                                            }
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website <?php echo date('Y'); ?></div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/chart-area-demo.js"></script>
        <script src="../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
